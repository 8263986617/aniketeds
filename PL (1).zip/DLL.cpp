#include <iostream>
using namespace std;

class Node {
public:
    int marks;
    Node* prev;
    Node* next;

    Node(int m) {
        marks = m;
        prev = NULL;
        next = NULL;
    }
};

class DoublyLinkedList {
    Node* head;

public:
    DoublyLinkedList() {
        head = NULL;
    }

    Node* getHead() {
        return head;
    }

    void insertEnd(int m);
    void display();
    void sort();
    static DoublyLinkedList mergeSorted(DoublyLinkedList l1, DoublyLinkedList l2);
};

// Insert at end
void DoublyLinkedList::insertEnd(int m) {
    Node* newNode = new Node(m);

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
}

// Display list
void DoublyLinkedList::display() {
    if (head == NULL) {
        cout << "List is empty\n";
        return;
    }

    Node* temp = head;
    while (temp != NULL) {
        cout << temp->marks << " ";
        temp = temp->next;
    }
    cout << endl;
}

// Sort list (Bubble Sort)
void DoublyLinkedList::sort() {
    if (head == NULL)
        return;

    for (Node* i = head; i->next != NULL; i = i->next) {
        for (Node* j = i->next; j != NULL; j = j->next) {
            if (i->marks > j->marks) {
                int temp = i->marks;
                i->marks = j->marks;
                j->marks = temp;
            }
        }
    }
}

// Merge two sorted lists
DoublyLinkedList DoublyLinkedList::mergeSorted(DoublyLinkedList l1, DoublyLinkedList l2) {
    DoublyLinkedList result;
    Node* p = l1.getHead();
    Node* q = l2.getHead();

    while (p != NULL && q != NULL) {
        if (p->marks <= q->marks) {
            result.insertEnd(p->marks);
            p = p->next;
        } else {
            result.insertEnd(q->marks);
            q = q->next;
        }
    }

    while (p != NULL) {
        result.insertEnd(p->marks);
        p = p->next;
    }

    while (q != NULL) {
        result.insertEnd(q->marks);
        q = q->next;
    }

    return result;
}

int main() {
    DoublyLinkedList list1, list2, merged;
    int n, m, value;

    cout << "Enter number of students in List 1: ";
    cin >> n;
    cout << "Enter marks for List 1:\n";
    for (int i = 0; i < n; i++) {
        cin >> value;
        list1.insertEnd(value);
    }

    cout << "Enter number of students in List 2: ";
    cin >> m;
    cout << "Enter marks for List 2:\n";
    for (int i = 0; i < m; i++) {
        cin >> value;
        list2.insertEnd(value);
    }

    cout << "\nList 1 before sorting: ";
    list1.display();
    cout << "List 2 before sorting: ";
    list2.display();

    list1.sort();
    list2.sort();

    cout << "\nList 1 after sorting: ";
    list1.display();
    cout << "List 2 after sorting: ";
    list2.display();

    merged = DoublyLinkedList::mergeSorted(list1, list2);

    cout << "\nMerged Sorted List: ";
    merged.display();

    return 0;
}
