#include <iostream>
using namespace std;

class Student {
public:
    int roll;
    char name[20];
    float sgpa;
    char dept[10];
};

// Swap function
void swapStudent(Student &a, Student &b) {
    Student temp = a;
    a = b;
    b = temp;
}

// Partition function (pivot = middle element)
int partition(Student s[], int low, int high) {
    float pivot = s[(low + high) / 2].sgpa;

    int i = low;
    int j = high;

    while (i <= j) {
        while (s[i].sgpa > pivot)
            i++;
        while (s[j].sgpa < pivot)
            j--;

        if (i <= j) {
            swapStudent(s[i], s[j]);
            i++;
            j--;
        }
    }
    return i;
}

// Quick Sort function
void quickSort(Student s[], int low, int high) {
    if (low < high) {
        int index = partition(s, low, high);
        quickSort(s, low, index - 1);
        quickSort(s, index, high);
    }
}

int main() {
    Student s[15] = {
        {1,"Amit",7.2,"IT"},
        {2,"Riya",9.3,"CS"},
        {3,"Kunal",6.9,"ME"},
        {4,"Sneha",9.1,"CS"},
        {5,"Rahul",7.5,"IT"},
        {6,"Neha",8.6,"CS"},
        {7,"Om",7.0,"ME"},
        {8,"Pooja",9.0,"CS"},
        {9,"Nikita",8.8,"CS"},
        {10,"Tejas",8.1,"ENTC"},
        {11,"Rohit",7.8,"IT"},
        {12,"Priya",8.0,"ENTC"},
        {13,"Shubham",8.2,"ENTC"},
        {14,"Sahil",7.9,"IT"},
        {15,"Aniket",8.4,"CS"}
    };

    int n = 15;

    // Quick Sort based on SGPA
    quickSort(s, 0, n - 1);

    // Display Top 10 Toppers
    cout << "\nTop 10 Toppers (Based on SGPA)\n";
    cout << "Roll\tName\tSGPA\tDepartment\n";

    for (int i = 0; i < 10; i++) {
        cout << s[i].roll << "\t"
             << s[i].name << "\t"
             << s[i].sgpa << "\t"
             << s[i].dept << endl;
    }

    return 0;
}
