#include <iostream>
#include <cstring>
using namespace std;

class Node {
public:
    int roll;
    char name[30];
    char company[30];
    float package;
    Node* next;

    Node(int r, char n[], char c[], float p) {
        roll = r;
        strcpy(name, n);
        strcpy(company, c);
        package = p;
        next = NULL;
    }
};

class PlacementSystem {
    Node* head;

public:
    PlacementSystem() {
        head = NULL;
    }

    void insert();
    void display();
    void search();
    void update();
    void remove();
    void sort();
};

// Insert record
void PlacementSystem::insert() {
    int r;
    char n[30], c[30];
    float p;

    cout << "Enter Roll No: ";
    cin >> r;
    cout << "Enter Name: ";
    cin >> n;
    cout << "Enter Company: ";
    cin >> c;
    cout << "Enter Package (LPA): ";
    cin >> p;

    Node* newNode = new Node(r, n, c, p);

    if (head == NULL)
        head = newNode;
    else {
        Node* temp = head;
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = newNode;
    }

    cout << "Record Inserted Successfully!\n";
}

// Display records
void PlacementSystem::display() {
    if (head == NULL) {
        cout << "No Records Found!\n";
        return;
    }

    Node* temp = head;
    cout << "\nRoll\tName\tCompany\tPackage\n";
    while (temp != NULL) {
        cout << temp->roll << "\t"
             << temp->name << "\t"
             << temp->company << "\t"
             << temp->package << endl;
        temp = temp->next;
    }
}

// Search record
void PlacementSystem::search() {
    int r;
    cout << "Enter Roll No to Search: ";
    cin >> r;

    Node* temp = head;
    while (temp != NULL) {
        if (temp->roll == r) {
            cout << "\nRecord Found:\n";
            cout << "Name: " << temp->name << endl;
            cout << "Company: " << temp->company << endl;
            cout << "Package: " << temp->package << endl;
            return;
        }
        temp = temp->next;
    }

    cout << "Record Not Found!\n";
}

// Update record
void PlacementSystem::update() {
    int r;
    cout << "Enter Roll No to Update: ";
    cin >> r;

    Node* temp = head;
    while (temp != NULL) {
        if (temp->roll == r) {
            cout << "Enter New Name: ";
            cin >> temp->name;
            cout << "Enter New Company: ";
            cin >> temp->company;
            cout << "Enter New Package: ";
            cin >> temp->package;
            cout << "Record Updated Successfully!\n";
            return;
        }
        temp = temp->next;
    }

    cout << "Record Not Found!\n";
}

// Delete record
void PlacementSystem::remove() {
    int r;
    cout << "Enter Roll No to Delete: ";
    cin >> r;

    Node* temp = head;
    Node* prev = NULL;

    while (temp != NULL) {
        if (temp->roll == r) {
            if (prev == NULL)
                head = temp->next;
            else
                prev->next = temp->next;

            delete temp;
            cout << "Record Deleted Successfully!\n";
            return;
        }
        prev = temp;
        temp = temp->next;
    }

    cout << "Record Not Found!\n";
}

// Sort records by package (ascending)
void PlacementSystem::sort() {
    if (head == NULL)
        return;

    for (Node* i = head; i->next != NULL; i = i->next) {
        for (Node* j = i->next; j != NULL; j = j->next) {
            if (i->package > j->package) {
                swap(i->roll, j->roll);
                swap(i->package, j->package);
                swap(i->name, j->name);
                swap(i->company, j->company);
            }
        }
    }

    cout << "Records Sorted by Package!\n";
}

int main() {
    PlacementSystem ps;
    int choice;

    do {
        cout << "\n--- Placement Information System ---\n";
        cout << "1. Insert Record\n";
        cout << "2. Display Records\n";
        cout << "3. Search Record\n";
        cout << "4. Update Record\n";
        cout << "5. Delete Record\n";
        cout << "6. Sort Records (by Package)\n";
        cout << "7. Exit\n";
        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice) {
            case 1: ps.insert(); break;
            case 2: ps.display(); break;
            case 3: ps.search(); break;
            case 4: ps.update(); break;
            case 5: ps.remove(); break;
            case 6: ps.sort(); break;
            case 7: cout << "Exiting Program...\n"; break;
            default: cout << "Invalid Choice!\n";
        }
    } while (choice != 7);

    return 0;
}
