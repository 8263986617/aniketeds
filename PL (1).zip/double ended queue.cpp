#include <iostream>
using namespace std;

#define SIZE 5

class Deque {
    int dq[SIZE];
    int front, rear;

public:
    Deque() {
        front = -1;
        rear = -1;
    }

    // Common operations
    bool isFull() {
        return (front == 0 && rear == SIZE - 1) || (front == rear + 1);
    }

    bool isEmpty() {
        return front == -1;
    }

    void display() {
        if (isEmpty()) {
            cout << "Deque is Empty\n";
            return;
        }

        int i = front;
        cout << "Deque Elements: ";
        while (true) {
            cout << dq[i] << " ";
            if (i == rear)
                break;
            i = (i + 1) % SIZE;
        }
        cout << endl;
    }

    // Insertion at rear
    void insertRear(int x) {
        if (isFull()) {
            cout << "Deque Overflow\n";
            return;
        }

        if (front == -1)
            front = rear = 0;
        else
            rear = (rear + 1) % SIZE;

        dq[rear] = x;
        cout << "Inserted at Rear\n";
    }

    // Insertion at front
    void insertFront(int x) {
        if (isFull()) {
            cout << "Deque Overflow\n";
            return;
        }

        if (front == -1)
            front = rear = 0;
        else if (front == 0)
            front = SIZE - 1;
        else
            front--;

        dq[front] = x;
        cout << "Inserted at Front\n";
    }

    // Deletion from front
    void deleteFront() {
        if (isEmpty()) {
            cout << "Deque Underflow\n";
            return;
        }

        cout << "Deleted Element: " << dq[front] << endl;

        if (front == rear)
            front = rear = -1;
        else
            front = (front + 1) % SIZE;
    }

    // Deletion from rear
    void deleteRear() {
        if (isEmpty()) {
            cout << "Deque Underflow\n";
            return;
        }

        cout << "Deleted Element: " << dq[rear] << endl;

        if (front == rear)
            front = rear = -1;
        else if (rear == 0)
            rear = SIZE - 1;
        else
            rear--;
    }
};

int main() {
    Deque d;
    int choice, value;

    cout << "\n--- Shopping Mall DEQUE System ---\n";
    cout << "1. Input Restricted Deque\n";
    cout << "2. Output Restricted Deque\n";
    cout << "Enter Choice: ";
    cin >> choice;

    int ch;
    if (choice == 1) {
        // Input Restricted Deque
        do {
            cout << "\n--- Input Restricted Deque ---\n";
            cout << "1. Insert at Rear\n";
            cout << "2. Delete from Front\n";
            cout << "3. Delete from Rear\n";
            cout << "4. Display\n";
            cout << "5. Exit\n";
            cout << "Enter choice: ";
            cin >> ch;

            switch (ch) {
                case 1:
                    cout << "Enter Token No: ";
                    cin >> value;
                    d.insertRear(value);
                    break;
                case 2:
                    d.deleteFront();
                    break;
                case 3:
                    d.deleteRear();
                    break;
                case 4:
                    d.display();
                    break;
            }
        } while (ch != 5);
    }
    else if (choice == 2) {
        // Output Restricted Deque
        do {
            cout << "\n--- Output Restricted Deque ---\n";
            cout << "1. Insert at Front\n";
            cout << "2. Insert at Rear\n";
            cout << "3. Delete from Front\n";
            cout << "4. Display\n";
            cout << "5. Exit\n";
            cout << "Enter choice: ";
            cin >> ch;

            switch (ch) {
                case 1:
                    cout << "Enter Token No: ";
                    cin >> value;
                    d.insertFront(value);
                    break;
                case 2:
                    cout << "Enter Token No: ";
                    cin >> value;
                    d.insertRear(value);
                    break;
                case 3:
                    d.deleteFront();
                    break;
                case 4:
                    d.display();
                    break;
            }
        } while (ch != 5);
    }
    else {
        cout << "Invalid Choice\n";
    }

    return 0;
}
