#include <iostream>
using namespace std;

class SparseMatrix {
    int rows, cols;
    int mat[50][50];
    int sparse[100][3];
    int nonZeroCount;

public:
    void input();
    void displayMatrix();
    void convert();
    void displaySparse();
    void SimpleTranspose();
    void FastTranspose();
    void Add(SparseMatrix s2);
    void Multiply(SparseMatrix s2);
};

// Input matrix
void SparseMatrix::input() {
    cout << "Enter number of rows: ";
    cin >> rows;
    cout << "Enter number of cols: ";
    cin >> cols;

    cout << "Enter matrix elements:\n";
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            cin >> mat[i][j];
}

// Display matrix
void SparseMatrix::displayMatrix() {
    cout << "\nMatrix:\n";
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++)
            cout << mat[i][j] << " ";
        cout << endl;
    }
}

// Convert to sparse
void SparseMatrix::convert() {
    nonZeroCount = 0;

    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            if (mat[i][j] != 0)
                nonZeroCount++;

    sparse[0][0] = rows;
    sparse[0][1] = cols;
    sparse[0][2] = nonZeroCount;

    int k = 1;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (mat[i][j] != 0) {
                sparse[k][0] = i;
                sparse[k][1] = j;
                sparse[k][2] = mat[i][j];
                k++;
            }
        }
    }
}

// Display sparse
void SparseMatrix::displaySparse() {
    cout << "\nSparse Matrix (row col value):\n";
    for (int i = 0; i <= nonZeroCount; i++)
        cout << sparse[i][0] << " "
             << sparse[i][1] << " "
             << sparse[i][2] << endl;
}

// 1. Simple Transpose
void SparseMatrix::SimpleTranspose() {
    int t[100][3], k = 1;

    t[0][0] = sparse[0][1];
    t[0][1] = sparse[0][0];
    t[0][2] = sparse[0][2];

    for (int col = 0; col < sparse[0][1]; col++) {
        for (int i = 1; i <= sparse[0][2]; i++) {
            if (sparse[i][1] == col) {
                t[k][0] = sparse[i][1];
                t[k][1] = sparse[i][0];
                t[k][2] = sparse[i][2];
                k++;
            }
        }
    }

    cout << "\nSimple Transpose:\n";
    for (int i = 0; i <= t[0][2]; i++)
        cout << t[i][0] << " " << t[i][1] << " " << t[i][2] << endl;
}

// 2. Fast Transpose
void SparseMatrix::FastTranspose() {
    int ft[100][3];
    int rowTerms[50] = {0}, startPos[50] = {0};

    ft[0][0] = sparse[0][1];
    ft[0][1] = sparse[0][0];
    ft[0][2] = sparse[0][2];

    for (int i = 1; i <= sparse[0][2]; i++)
        rowTerms[sparse[i][1]]++;

    startPos[0] = 1;
    for (int i = 1; i < sparse[0][1]; i++)
        startPos[i] = startPos[i - 1] + rowTerms[i - 1];

    for (int i = 1; i <= sparse[0][2]; i++) {
        int pos = startPos[sparse[i][1]]++;
        ft[pos][0] = sparse[i][1];
        ft[pos][1] = sparse[i][0];
        ft[pos][2] = sparse[i][2];
    }

    cout << "\nFast Transpose:\n";
    for (int i = 0; i <= ft[0][2]; i++)
        cout << ft[i][0] << " " << ft[i][1] << " " << ft[i][2] << endl;
}

// 3. Addition
void SparseMatrix::Add(SparseMatrix s2) {
    if (rows != s2.rows || cols != s2.cols) {
        cout << "\nAddition not possible\n";
        return;
    }

    int i = 1, j = 1, k = 1;
    int result[100][3];

    result[0][0] = rows;
    result[0][1] = cols;

    while (i <= nonZeroCount && j <= s2.nonZeroCount) {
        if (sparse[i][0] == s2.sparse[j][0] &&
            sparse[i][1] == s2.sparse[j][1]) {

            result[k][0] = sparse[i][0];
            result[k][1] = sparse[i][1];
            result[k][2] = sparse[i][2] + s2.sparse[j][2];
            i++; j++; k++;
        }
        else if (sparse[i][0] < s2.sparse[j][0]) {
            result[k][0] = sparse[i][0];
            result[k][1] = sparse[i][1];
            result[k][2] = sparse[i][2];
            i++; k++;
        }
        else {
            result[k][0] = s2.sparse[j][0];
            result[k][1] = s2.sparse[j][1];
            result[k][2] = s2.sparse[j][2];
            j++; k++;
        }
    }

    result[0][2] = k - 1;

    cout << "\nAddition Result:\n";
    for (int x = 0; x < k; x++)
        cout << result[x][0] << " " << result[x][1] << " " << result[x][2] << endl;
}

// 4. Multiplication
void SparseMatrix::Multiply(SparseMatrix s2) {
    if (cols != s2.rows) {
        cout << "\nMultiplication not possible\n";
        return;
    }

    int result[100][3], k = 1;

    result[0][0] = rows;
    result[0][1] = s2.cols;

    for (int i = 1; i <= nonZeroCount; i++) {
        for (int j = 1; j <= s2.nonZeroCount; j++) {
            if (sparse[i][1] == s2.sparse[j][0]) {
                result[k][0] = sparse[i][0];
                result[k][1] = s2.sparse[j][1];
                result[k][2] = sparse[i][2] * s2.sparse[j][2];
                k++;
            }
        }
    }

    result[0][2] = k - 1;

    cout << "\nMultiplication Result:\n";
    for (int i = 0; i < k; i++)
        cout << result[i][0] << " " << result[i][1] << " " << result[i][2] << endl;
}

int main() {
    SparseMatrix s1, s2;

    cout << "\nEnter First Matrix\n";
    s1.input();
    s1.displayMatrix();
    s1.convert();
    s1.displaySparse();

    s1.SimpleTranspose();
    s1.FastTranspose();

    cout << "\nEnter Second Matrix\n";
    s2.input();
    s2.convert();

    s1.Add(s2);
    s1.Multiply(s2);

    return 0;
}
