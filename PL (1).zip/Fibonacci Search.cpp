#include <iostream>
#include <cstring>
using namespace std;

class Student {
public:
    int roll;
    char name[20];
    float sgpa;
    char dept[15];
};

// Bubble sort by name (required for Fibonacci search)
void sortByName(Student s[], int n) {
    Student temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (strcmp(s[j].name, s[j + 1].name) > 0) {
                temp = s[j];
                s[j] = s[j + 1];
                s[j + 1] = temp;
            }
        }
    }
}

// Fibonacci Search by student name
void fibonacciSearch(Student s[], int n, char key[]) {
    int fib2 = 0;     // (m-2)th Fibonacci
    int fib1 = 1;     // (m-1)th Fibonacci
    int fib = fib1 + fib2;  // mth Fibonacci

    while (fib < n) {
        fib2 = fib1;
        fib1 = fib;
        fib = fib1 + fib2;
    }

    int offset = -1;

    while (fib > 1) {
        int i = (offset + fib2 < n) ? offset + fib2 : n - 1;

        if (strcmp(s[i].name, key) < 0) {
            fib = fib1;
            fib1 = fib2;
            fib2 = fib - fib1;
            offset = i;
        }
        else if (strcmp(s[i].name, key) > 0) {
            fib = fib2;
            fib1 = fib1 - fib2;
            fib2 = fib - fib1;
        }
        else {
            cout << "\nStudent Found:\n";
            cout << "Roll: " << s[i].roll << endl;
            cout << "Name: " << s[i].name << endl;
            cout << "Department: " << s[i].dept << endl;

            if (strcmp(s[i].dept, "CS") == 0 || strcmp(s[i].dept, "Computer") == 0)
                cout << "Student belongs to Computer Department.\n";
            else
                cout << "Student does NOT belong to Computer Department.\n";
            return;
        }
    }

    // Check last element
    if (fib1 && offset + 1 < n && strcmp(s[offset + 1].name, key) == 0) {
        int i = offset + 1;
        cout << "\nStudent Found:\n";
        cout << "Roll: " << s[i].roll << endl;
        cout << "Name: " << s[i].name << endl;
        cout << "Department: " << s[i].dept << endl;

        if (strcmp(s[i].dept, "CS") == 0 || strcmp(s[i].dept, "Computer") == 0)
            cout << "Student belongs to Computer Department.\n";
        else
            cout << "Student does NOT belong to Computer Department.\n";
        return;
    }

    cout << "Student not found!\n";
}

int main() {
    Student s[15] = {
        {1,"Amit",7.2,"IT"},
        {2,"Riya",9.3,"CS"},
        {3,"Kunal",8.4,"ME"},
        {4,"Sneha",9.1,"CS"},
        {5,"Rahul",7.5,"IT"},
        {6,"Neha",8.6,"CS"},
        {7,"Om",7.0,"ME"},
        {8,"Pooja",9.0,"CS"},
        {9,"Nikita",8.8,"CS"},
        {10,"Tejas",8.1,"ENTC"},
        {11,"Rohit",7.8,"IT"},
        {12,"Priya",8.0,"ENTC"},
        {13,"Shubham",8.2,"ENTC"},
        {14,"Sahil",7.9,"IT"},
        {15,"Aniket",8.4,"CS"}
    };

    int n = 15;
    char key[20];

    // Sort before Fibonacci search
    sortByName(s, n);

    cout << "Enter Student Name to Search: ";
    cin >> key;

    fibonacciSearch(s, n, key);

    return 0;
}
