#include <iostream>
using namespace std;

class Customer {
public:
    int id;
    char name[30];
    char city[20];
    float balance;
};

class CustomerManagement {
    Customer cust[50];   // array of customers
    int count;           // current number of customers

public:
    CustomerManagement() {
        count = 0;
    }

    void insert();
    void display();
    void update();
    void remove();
    void search();
};

void CustomerManagement::insert() {
    cout << "\nEnter Customer ID: ";
    cin >> cust[count].id;
    cout << "Enter Name: ";
    cin >> cust[count].name;
    cout << "Enter City: ";
    cin >> cust[count].city;
    cout << "Enter Balance: ";
    cin >> cust[count].balance;

    count++;
    cout << "Customer Added Successfully!\n";
}

void CustomerManagement::display() {
    if (count == 0) {
        cout << "\nNo Records Found!\n";
        return;
    }

    cout << "\nID\tName\tCity\tBalance\n";
    for (int i = 0; i < count; i++) {
        cout << cust[i].id << "\t"
             << cust[i].name << "\t"
             << cust[i].city << "\t"
             << cust[i].balance << endl;
    }
}

void CustomerManagement::update() {
    int id, found = 0;
    cout << "\nEnter Customer ID to Update: ";
    cin >> id;

    for (int i = 0; i < count; i++) {
        if (cust[i].id == id) {
            cout << "Enter New Name: ";
            cin >> cust[i].name;
            cout << "Enter New City: ";
            cin >> cust[i].city;
            cout << "Enter New Balance: ";
            cin >> cust[i].balance;
            found = 1;
            cout << "Record Updated Successfully!\n";
            break;
        }
    }

    if (!found)
        cout << "Customer Not Found!\n";
}

void CustomerManagement::remove() {
    int id, found = 0;
    cout << "\nEnter Customer ID to Delete: ";
    cin >> id;

    for (int i = 0; i < count; i++) {
        if (cust[i].id == id) {
            for (int j = i; j < count - 1; j++) {
                cust[j] = cust[j + 1];
            }
            count--;
            found = 1;
            cout << "Customer Deleted Successfully!\n";
            break;
        }
    }

    if (!found)
        cout << "Customer Not Found!\n";
}

void CustomerManagement::search() {
    int id, found = 0;
    cout << "\nEnter Customer ID to Search: ";
    cin >> id;

    for (int i = 0; i < count; i++) {
        if (cust[i].id == id) {
            cout << "\nCustomer Found:\n";
            cout << "ID: " << cust[i].id << endl;
            cout << "Name: " << cust[i].name << endl;
            cout << "City: " << cust[i].city << endl;
            cout << "Balance: " << cust[i].balance << endl;
            found = 1;
            break;
        }
    }

    if (!found)
        cout << "Customer Not Found!\n";
}

int main() {
    CustomerManagement cm;
    int choice;

    do {
        cout << "\n--- Customer Management System ---\n";
        cout << "1. Insert Customer\n";
        cout << "2. Display Customers\n";
        cout << "3. Update Customer\n";
        cout << "4. Delete Customer\n";
        cout << "5. Search Customer\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: cm.insert(); break;
            case 2: cm.display(); break;
            case 3: cm.update(); break;
            case 4: cm.remove(); break;
            case 5: cm.search(); break;
            case 6: cout << "Exiting Program...\n"; break;
            default: cout << "Invalid Choice!\n";
        }
    } while (choice != 6);

    return 0;
}
