#include <iostream>
using namespace std;

class Student {
public:
    int roll;
    char name[20];
    float sgpa;
    char dept[10];
};

int main() {
    Student s[15] = {
        {23,"Aniket",8.4,"CS"},
        {12,"Rohit",7.8,"IT"},
        {45,"Sneha",9.1,"CS"},
        {34,"Priya",8.0,"ENTC"},
        {7,"Amit",7.2,"IT"},
        {19,"Neha",8.6,"CS"},
        {3,"Kunal",6.9,"ME"},
        {27,"Pooja",9.0,"CS"},
        {15,"Rahul",7.5,"IT"},
        {41,"Shubham",8.2,"ENTC"},
        {9,"Nikita",8.8,"CS"},
        {30,"Om",7.0,"ME"},
        {2,"Riya",9.3,"CS"},
        {18,"Sahil",7.9,"IT"},
        {25,"Tejas",8.1,"ENTC"}
    };

    int n = 15;
    Student temp;

    // Bubble Sort based on Roll Number
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (s[j].roll > s[j + 1].roll) {
                temp = s[j];
                s[j] = s[j + 1];
                s[j + 1] = temp;
            }
        }
    }

    // Display Roll Call List
    cout << "\nRoll Call List (Ascending Order of Roll No)\n";
    cout << "Roll\tName\tSGPA\tDepartment\n";

    for (int i = 0; i < n; i++) {
        cout << s[i].roll << "\t"
             << s[i].name << "\t"
             << s[i].sgpa << "\t"
             << s[i].dept << endl;
    }

    return 0;
}
