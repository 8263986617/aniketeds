#include <iostream>
#include <cstring>
using namespace std;

class Student {
public:
    int roll;
    char name[20];
    float sgpa;
    char dept[10];
};

int main() {
    Student s[15] = {
        {23,"Aniket",8.4,"CS"},
        {12,"Rohit",7.8,"IT"},
        {45,"Sneha",9.1,"CS"},
        {34,"Priya",8.0,"ENTC"},
        {7,"Amit",7.2,"IT"},
        {19,"Neha",8.6,"CS"},
        {3,"Kunal",6.9,"ME"},
        {27,"Pooja",9.0,"CS"},
        {15,"Rahul",7.5,"IT"},
        {41,"Shubham",8.2,"ENTC"},
        {9,"Nikita",8.8,"CS"},
        {30,"Om",7.0,"ME"},
        {2,"Riya",9.3,"CS"},
        {18,"Sahil",7.9,"IT"},
        {25,"Tejas",8.1,"ENTC"}
    };

    int n = 15;
    Student key;

    // Insertion Sort based on Name (Alphabetical Order)
    for (int i = 1; i < n; i++) {
        key = s[i];
        int j = i - 1;

        while (j >= 0 && strcmp(s[j].name, key.name) > 0) {
            s[j + 1] = s[j];
            j--;
        }
        s[j + 1] = key;
    }

    // Display Alphabetical List
    cout << "\nStudent List (Alphabetical Order by Name)\n";
    cout << "Roll\tName\tSGPA\tDepartment\n";

    for (int i = 0; i < n; i++) {
        cout << s[i].roll << "\t"
             << s[i].name << "\t"
             << s[i].sgpa << "\t"
             << s[i].dept << endl;
    }

    return 0;
}
