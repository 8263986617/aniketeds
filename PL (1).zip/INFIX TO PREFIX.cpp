#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

class Stack {
    int top;
    char s[50];

public:
    Stack() {
        top = -1;
    }

    void push(char x) {
        s[++top] = x;
    }

    char pop() {
        return s[top--];
    }

    char peek() {
        return s[top];
    }

    int isEmpty() {
        return top == -1;
    }
};

// ---------- Operator Priority ----------
int priority(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

// ---------- a) Prefix to Infix ----------
void prefixToInfix(char prefix[]) {
    Stack st;
    char infix[50][50];
    int top = -1;

    for (int i = strlen(prefix) - 1; i >= 0; i--) {
        char ch = prefix[i];

        if (isalnum(ch)) {
            char temp[2] = {ch, '\0'};
            strcpy(infix[++top], temp);
        } else {
            char op1[50], op2[50], expr[50];
            strcpy(op1, infix[top--]);
            strcpy(op2, infix[top--]);

            sprintf(expr, "(%s%c%s)", op1, ch, op2);
            strcpy(infix[++top], expr);
        }
    }

    cout << "Infix Expression: " << infix[top] << endl;
}

// ---------- b) Infix to Postfix ----------
void infixToPostfix(char infix[]) {
    Stack st;
    char postfix[50];
    int k = 0;

    for (int i = 0; infix[i] != '\0'; i++) {
        char ch = infix[i];

        if (isalnum(ch)) {
            postfix[k++] = ch;
        }
        else if (ch == '(') {
            st.push(ch);
        }
        else if (ch == ')') {
            while (!st.isEmpty() && st.peek() != '(')
                postfix[k++] = st.pop();
            st.pop();
        }
        else {
            while (!st.isEmpty() && priority(st.peek()) >= priority(ch))
                postfix[k++] = st.pop();
            st.push(ch);
        }
    }

    while (!st.isEmpty())
        postfix[k++] = st.pop();

    postfix[k] = '\0';
    cout << "Postfix Expression: " << postfix << endl;
}

// ---------- c) Postfix Evaluation ----------
int postfixEvaluation(char postfix[]) {
    int stack[50], top = -1;

    for (int i = 0; postfix[i] != '\0'; i++) {
        char ch = postfix[i];

        if (isdigit(ch)) {
            stack[++top] = ch - '0';
        } else {
            int b = stack[top--];
            int a = stack[top--];

            switch (ch) {
                case '+': stack[++top] = a + b; break;
                case '-': stack[++top] = a - b; break;
                case '*': stack[++top] = a * b; break;
                case '/': stack[++top] = a / b; break;
            }
        }
    }
    return stack[top];
}

// ---------- MAIN ----------
int main() {
    char prefix[50], infix[50], postfix[50];

    cout << "Enter Prefix Expression: ";
    cin >> prefix;
    prefixToInfix(prefix);

    cout << "\nEnter Infix Expression: ";
    cin >> infix;
    infixToPostfix(infix);

    cout << "\nEnter Postfix Expression (single digit operands): ";
    cin >> postfix;
    cout << "Postfix Evaluation Result: "
         << postfixEvaluation(postfix) << endl;

    return 0;
}
