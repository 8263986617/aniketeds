#include <iostream>
using namespace std;

class Order {
public:
    int orderId;
    Order* next;

    Order(int id) {
        orderId = id;
        next = NULL;
    }
};

class PizzaParlor {
    Order* front;
    Order* rear;
    int maxOrders;
    int count;

public:
    PizzaParlor(int m) {
        front = rear = NULL;
        maxOrders = m;
        count = 0;
    }

    void placeOrder();
    void serveOrder();
    void displayOrders();
};

// Place order (enqueue)
void PizzaParlor::placeOrder() {
    if (count == maxOrders) {
        cout << "Pizza Parlor is Full! Cannot accept more orders.\n";
        return;
    }

    int id;
    cout << "Enter Order ID: ";
    cin >> id;

    Order* newOrder = new Order(id);

    if (front == NULL) {
        front = rear = newOrder;
        rear->next = front;   // circular link
    } else {
        rear->next = newOrder;
        rear = newOrder;
        rear->next = front;
    }

    count++;
    cout << "Order Placed Successfully!\n";
}

// Serve order (dequeue)
void PizzaParlor::serveOrder() {
    if (front == NULL) {
        cout << "No Orders to Serve!\n";
        return;
    }

    Order* temp = front;
    cout << "Serving Order ID: " << temp->orderId << endl;

    if (front == rear) {
        front = rear = NULL;
    } else {
        front = front->next;
        rear->next = front;
    }

    delete temp;
    count--;
}

// Display orders
void PizzaParlor::displayOrders() {
    if (front == NULL) {
        cout << "No Pending Orders!\n";
        return;
    }

    Order* temp = front;
    cout << "Pending Orders: ";
    do {
        cout << temp->orderId << " ";
        temp = temp->next;
    } while (temp != front);

    cout << endl;
}

int main() {
    int m, choice;
    cout << "Enter Maximum Number of Orders: ";
    cin >> m;

    PizzaParlor p(m);

    do {
        cout << "\n--- Pizza Parlor Menu ---\n";
        cout << "1. Place Order\n";
        cout << "2. Serve Order\n";
        cout << "3. Display Orders\n";
        cout << "4. Exit\n";
        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice) {
            case 1: p.placeOrder(); break;
            case 2: p.serveOrder(); break;
            case 3: p.displayOrders(); break;
            case 4: cout << "Exiting System...\n"; break;
            default: cout << "Invalid Choice!\n";
        }
    } while (choice != 4);

    return 0;
}
