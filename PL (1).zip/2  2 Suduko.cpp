#include <iostream>
using namespace std;

#define N 4   // 4x4 Sudoku

// Function to print the Sudoku
void printGrid(int grid[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cout << grid[i][j] << " ";
        }
        cout << endl;
    }
}

// Check if number can be placed safely
bool isSafe(int grid[N][N], int row, int col, int num) {

    // Check row
    for (int x = 0; x < N; x++)
        if (grid[row][x] == num)
            return false;

    // Check column
    for (int x = 0; x < N; x++)
        if (grid[x][col] == num)
            return false;

    // Check 2x2 subgrid
    int startRow = row - row % 2;
    int startCol = col - col % 2;

    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            if (grid[startRow + i][startCol + j] == num)
                return false;

    return true;
}

// Recursive Backtracking Sudoku Solver
bool solveSudoku(int grid[N][N]) {
    int row, col;
    bool emptyFound = false;

    // Find empty cell
    for (row = 0; row < N; row++) {
        for (col = 0; col < N; col++) {
            if (grid[row][col] == 0) {
                emptyFound = true;
                break;
            }
        }
        if (emptyFound)
            break;
    }

    // If no empty cell found ? solved
    if (!emptyFound)
        return true;

    // Try numbers 1 to 4
    for (int num = 1; num <= 4; num++) {
        if (isSafe(grid, row, col, num)) {
            grid[row][col] = num;

            if (solveSudoku(grid))
                return true;

            // Backtracking
            grid[row][col] = 0;
        }
    }

    return false;
}

int main() {
    int grid[N][N] = {
        {1, 0, 0, 4},
        {0, 0, 3, 1},
        {0, 1, 0, 0},
        {2, 0, 0, 3}
    };

    cout << "Original Sudoku:\n";
    printGrid(grid);

    if (solveSudoku(grid)) {
        cout << "\nSolved Sudoku:\n";
        printGrid(grid);
    } else {
        cout << "No solution exists!\n";
    }

    return 0;
}
