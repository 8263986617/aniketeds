#include <iostream>
using namespace std;

#define N 5

class RoundRobin {
    int pid[N];
    int at[N];
    int bt[N];
    int rt[N];   // remaining time
    int ct[N];   // completion time
    int wt[N];   // waiting time
    int tat[N];  // turnaround time

    int queue[20];
    int front, rear;
    int tq;

public:
    RoundRobin() {
        front = rear = -1;
        tq = 2;   // time quantum
    }

    void input();
    void schedule();
    void display();
    void enqueue(int x);
    int dequeue();
    bool isEmpty();
};

void RoundRobin::input() {
    int p[5] = {1, 2, 3, 4, 5};
    int a[5] = {0, 1, 2, 3, 4};
    int b[5] = {5, 3, 1, 2, 3};

    for (int i = 0; i < N; i++) {
        pid[i] = p[i];
        at[i] = a[i];
        bt[i] = b[i];
        rt[i] = bt[i];
    }
}

// Circular Queue Operations
void RoundRobin::enqueue(int x) {
    if (front == -1) {
        front = rear = 0;
        queue[rear] = x;
    } else {
        rear = (rear + 1) % 20;
        queue[rear] = x;
    }
}

int RoundRobin::dequeue() {
    int x = queue[front];
    if (front == rear)
        front = rear = -1;
    else
        front = (front + 1) % 20;
    return x;
}

bool RoundRobin::isEmpty() {
    return front == -1;
}

// Round Robin Scheduling
void RoundRobin::schedule() {
    int time = 0, completed = 0;
    bool visited[N] = {false};

    enqueue(0);
    visited[0] = true;

    while (completed < N) {
        int i = dequeue();

        if (rt[i] > tq) {
            time += tq;
            rt[i] -= tq;
        } else {
            time += rt[i];
            rt[i] = 0;
            ct[i] = time;
            completed++;
        }

        // Add newly arrived processes
        for (int j = 0; j < N; j++) {
            if (at[j] <= time && !visited[j]) {
                enqueue(j);
                visited[j] = true;
            }
        }

        if (rt[i] > 0)
            enqueue(i);
    }

    // Calculate TAT & WT
    for (int i = 0; i < N; i++) {
        tat[i] = ct[i] - at[i];
        wt[i] = tat[i] - bt[i];
    }
}

// Display result
void RoundRobin::display() {
    float avgWT = 0, avgTAT = 0;

    cout << "\nProcess\tAT\tBT\tCT\tTAT\tWT\n";
    for (int i = 0; i < N; i++) {
        cout << "P" << pid[i] << "\t"
             << at[i] << "\t"
             << bt[i] << "\t"
             << ct[i] << "\t"
             << tat[i] << "\t"
             << wt[i] << endl;

        avgWT += wt[i];
        avgTAT += tat[i];
    }

    cout << "\nAverage Waiting Time = " << avgWT / N;
    cout << "\nAverage Turnaround Time = " << avgTAT / N << endl;
}

int main() {
    RoundRobin rr;

    rr.input();
    rr.schedule();
    rr.display();

    return 0;
}
