// b) Marks out of 100 of 20 students needs to be stored in a table using hash function hash (key) = key mod 20 where key is the data to be inserted into the Hash table. Write a C++ program to implement hash table for collision handling using separate chaining without replacement using linked list for the following data :- 33,56,78,12,10,67,89,99,100,23,45,71,39,62,59,90,91,20,75,66. 

#include <iostream>
using namespace std;

#define SIZE 20

// Node for linked list
class Node {
public:
    int data;
    Node* next;

    Node(int d) {
        data = d;
        next = NULL;
    }
};

class HashTable {
    Node* table[SIZE];

public:
    HashTable() {
        for (int i = 0; i < SIZE; i++)
            table[i] = NULL;
    }

    int hashFunction(int key) {
        return key % SIZE;
    }

    // Insert using Separate Chaining (Without Replacement)
    void insert(int key) {
        int index = hashFunction(key);

        Node* newNode = new Node(key);

        if (table[index] == NULL) {
            table[index] = newNode;
        } else {
            Node* temp = table[index];
            while (temp->next != NULL)
                temp = temp->next;
            temp->next = newNode;
        }
    }

    // Display hash table
    void display() {
        cout << "\nHash Table (Separate Chaining):\n";
        for (int i = 0; i < SIZE; i++) {
            cout << i << " : ";
            Node* temp = table[i];
            if (temp == NULL) {
                cout << "NULL";
            } else {
                while (temp != NULL) {
                    cout << temp->data << " -> ";
                    temp = temp->next;
                }
                cout << "NULL";
            }
            cout << endl;
        }
    }
};

int main() {
    HashTable ht;

    int marks[20] = {
        33,56,78,12,10,67,89,99,100,23,
        45,71,39,62,59,90,91,20,75,66
    };

    for (int i = 0; i < 20; i++) {
        ht.insert(marks[i]);
    }

    ht.display();
    return 0;
}
