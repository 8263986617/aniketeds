// c) Lalit has a fresh mango fruit shop and he wants to store information about 11 varieties of mangoes available in a table using hash function hash (key) = key mod 11 where key is the number of mangoes of each category . write a C++ program to implement hash table for collision handling using quadratic probing without replacement for the following data. 

//Category 1 2 3 4 5 6 7 8 9 10 11 

//No of Mangoes 25 15 10 5 11 19 16 36 42 28 32 

#include <iostream>
using namespace std;

#define SIZE 11

class HashTable {
    int table[SIZE];

public:
    HashTable() {
        for (int i = 0; i < SIZE; i++)
            table[i] = -1;   // initialize table
    }

    int hashFunction(int key) {
        return key % SIZE;
    }

    // Insert using Quadratic Probing (Without Replacement)
    void insert(int key) {
        int index = hashFunction(key);

        if (table[index] == -1) {
            table[index] = key;
            return;
        }

        // Quadratic probing
        for (int i = 1; i < SIZE; i++) {
            int newIndex = (index + i * i) % SIZE;
            if (table[newIndex] == -1) {
                table[newIndex] = key;
                return;
            }
        }

        cout << "Hash table is full. Cannot insert " << key << endl;
    }

    // Display hash table
    void display() {
        cout << "\nHash Table (Quadratic Probing):\n";
        for (int i = 0; i < SIZE; i++) {
            if (table[i] != -1)
                cout << i << " --> " << table[i] << endl;
            else
                cout << i << " --> Empty\n";
        }
    }
};

int main() {
    HashTable ht;

    int mangoes[11] = {25,15,10,5,11,19,16,36,42,28,32};

    for (int i = 0; i < 11; i++) {
        ht.insert(mangoes[i]);
    }

    ht.display();
    return 0;
}
