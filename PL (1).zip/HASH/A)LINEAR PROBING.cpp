//a) Raman has a cold drink corner shop in he wants to store information about different flavours of cold drink available in a table using hash function hash (key) = key mod 6 where key is the data to be inserted into the Hash table. Write a C++ program to implement hash table for collision handling using linear probing without chaining without replacement

#include <iostream>
using namespace std;

#define SIZE 6

class HashTable {
    int table[SIZE];

public:
    HashTable() {
        for (int i = 0; i < SIZE; i++)
            table[i] = -1;   // initialize table
    }

    int hashFunction(int key) {
        return key % SIZE;
    }

    // Insert using Linear Probing (Without Replacement)
    void insert(int key) {
        int index = hashFunction(key);

        if (table[index] == -1) {
            table[index] = key;
        } else {
            // Linear probing
            int i = (index + 1) % SIZE;
            while (i != index) {
                if (table[i] == -1) {
                    table[i] = key;
                    return;
                }
                i = (i + 1) % SIZE;
            }
            cout << "Hash Table is Full! Cannot insert " << key << endl;
        }
    }

    // Display hash table
    void display() {
        cout << "\nHash Table:\n";
        for (int i = 0; i < SIZE; i++) {
            if (table[i] != -1)
                cout << i << " --> " << table[i] << endl;
            else
                cout << i << " --> Empty\n";
        }
    }
};

int main() {
    HashTable ht;
    int n, key;

    cout << "Enter number of cold drink flavours to insert: ";
    cin >> n;

    cout << "Enter flavour keys:\n";
    for (int i = 0; i < n; i++) {
        cin >> key;
        ht.insert(key);
    }

    ht.display();
    return 0;
}
