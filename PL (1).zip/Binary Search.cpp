#include <iostream>
#include <cstring>
using namespace std;

class Student {
public:
    int roll;
    char name[20];
    float sgpa;
    char dept[10];
};

// Bubble sort to sort students alphabetically by name
void sortByName(Student s[], int n) {
    Student temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (strcmp(s[j].name, s[j + 1].name) > 0) {
                temp = s[j];
                s[j] = s[j + 1];
                s[j + 1] = temp;
            }
        }
    }
}

// Binary Search (Non-Recursive) to find all matching names
void binarySearchByName(Student s[], int n, char key[]) {
    int low = 0, high = n - 1, mid;
    int found = -1;

    // Binary search loop
    while (low <= high) {
        mid = (low + high) / 2;

        if (strcmp(s[mid].name, key) == 0) {
            found = mid;
            break;
        }
        else if (strcmp(s[mid].name, key) < 0)
            low = mid + 1;
        else
            high = mid - 1;
    }

    if (found == -1) {
        cout << "Student not found!\n";
        return;
    }

    // Print all students with same name
    cout << "\nStudent(s) Found:\n";
    cout << "Roll\tName\tSGPA\tDepartment\n";

    // Check left side
    int i = found;
    while (i >= 0 && strcmp(s[i].name, key) == 0)
        i--;

    // Print all matches
    i++;
    while (i < n && strcmp(s[i].name, key) == 0) {
        cout << s[i].roll << "\t"
             << s[i].name << "\t"
             << s[i].sgpa << "\t"
             << s[i].dept << endl;
        i++;
    }
}

int main() {
    Student s[15] = {
        {1,"Amit",7.2,"IT"},
        {2,"Riya",9.3,"CS"},
        {3,"Kunal",8.4,"ME"},
        {4,"Sneha",9.1,"CS"},
        {5,"Rahul",7.5,"IT"},
        {6,"Neha",8.6,"CS"},
        {7,"Om",7.0,"ME"},
        {8,"Pooja",9.0,"CS"},
        {9,"Amit",8.1,"CS"},
        {10,"Tejas",8.1,"ENTC"},
        {11,"Rohit",7.8,"IT"},
        {12,"Priya",8.0,"ENTC"},
        {13,"Shubham",8.2,"ENTC"},
        {14,"Amit",7.9,"IT"},
        {15,"Aniket",8.4,"CS"}
    };

    int n = 15;
    char key[20];

    // Sort before binary search
    sortByName(s, n);

    cout << "Enter Name to Search: ";
    cin >> key;

    binarySearchByName(s, n, key);

    return 0;
}
