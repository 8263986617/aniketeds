#include <iostream>
using namespace std;

class Student {
public:
    int roll;
    char name[20];
    float sgpa;
    char dept[10];
};

int main() {
    Student s[15] = {
        {1,"Amit",7.2,"IT"},
        {2,"Riya",9.3,"CS"},
        {3,"Kunal",8.4,"ME"},
        {4,"Sneha",9.1,"CS"},
        {5,"Rahul",7.5,"IT"},
        {6,"Neha",8.6,"CS"},
        {7,"Om",7.0,"ME"},
        {8,"Pooja",9.0,"CS"},
        {9,"Nikita",8.4,"CS"},
        {10,"Tejas",8.1,"ENTC"},
        {11,"Rohit",7.8,"IT"},
        {12,"Priya",8.0,"ENTC"},
        {13,"Shubham",8.2,"ENTC"},
        {14,"Sahil",7.5,"IT"},
        {15,"Aniket",8.4,"CS"}
    };

    float key;
    int found = 0;

    cout << "Enter SGPA to search: ";
    cin >> key;

    cout << "\nStudents having SGPA " << key << ":\n";
    cout << "Roll\tName\tSGPA\tDepartment\n";

    // Linear Search
    for (int i = 0; i < 15; i++) {
        if (s[i].sgpa == key) {
            cout << s[i].roll << "\t"
                 << s[i].name << "\t"
                 << s[i].sgpa << "\t"
                 << s[i].dept << endl;
            found = 1;
        }
    }

    if (!found)
        cout << "No student found with given SGPA.\n";

    return 0;
}
